import torchvision
import torch
import cv2 as cv
import numpy as np
from PIL import Image

import matplotlib.pyplot as plt

from configs.args import args
from model.mask_rcnn import *
import data.transforms as T
from data.dataset import PennFudanDataset, get_transform

# define model
model = mask_rcnn(num_classes=2)
# load checkpoint
state_dict = torch.load(args.checkpoint)
model.load_state_dict(state_dict)
model.eval()
transform = T.Compose([T.ToTensor()])

# 使用GPU
train_on_gpu = torch.cuda.is_available()
if train_on_gpu:
    model.cuda()


def object_detection__demo():
    img = cv.imread(".../PennFudanPed/PNGImages/FudanPed00037.png")
    mask_path = ".../PennFudanPed/PedMasks/FudanPed00037_mask.png"
    mask = Image.open(mask_path)

    mask = np.array(mask)
    obj_ids = np.unique(mask)
    obj_ids = obj_ids[1:]

    masks = mask == obj_ids[:, None, None]

    num_objs = len(obj_ids)
    boxes = []
    for i in range(num_objs):
        pos = np.where(masks[i])
        xmin = np.min(pos[1])
        xmax = np.max(pos[1])
        ymin = np.min(pos[0])
        ymax = np.max(pos[0])
        boxes.append([xmin, ymin, xmax, ymax])

    boxes = torch.as_tensor(boxes, dtype=torch.float32)
    labels = torch.ones((num_objs,), dtype=torch.int64)
    masks = torch.as_tensor(masks, dtype=torch.uint8)

    image_id = torch.tensor([1])
    area = (boxes[:, 3] - boxes[:, 1]) * (boxes[:, 2] - boxes[:, 0])
    iscrowd = torch.zeros((num_objs,), dtype=torch.int64)

    target = {}
    target["boxes"] = boxes
    target["labels"] = labels
    target["masks"] = masks
    target["image_id"] = image_id
    target["area"] = area
    target["iscrowd"] = iscrowd

    frame = cv.cvtColor(img, cv.COLOR_BGR2RGB)
    blob = transform(frame, target)
    # print(blob[0])
    c, h, w = blob[0].shape
    input_x = blob[0].view(1, c, h, w)
    output = model(input_x.cuda())[0]
    boxes = output['boxes'].cpu().detach().numpy()
    scores = output['scores'].cpu().detach().numpy()
    labels = output['labels'].cpu().detach().numpy()
    index = 0
    frame = cv.cvtColor(frame, cv.COLOR_RGB2BGR)
    for x1, y1, x2, y2 in boxes:
        if scores[index] > 0.9:
            print("score: ", scores[index])
            cv.rectangle(frame, (np.int32(x1), np.int32(y1)), (np.int32(x2), np.int32(y2)), (0, 0, 255), 2, 8, 0)
            index += 1

    cv.imshow("Mask-RCNN Demo", frame)
    cv.imwrite(".../基于Mask R-CNN 模型的行人识别/FudanPed00037mask_rcnn.png", frame)
    cv.waitKey(0)
    cv.destroyAllWindows()


if __name__ == "__main__":
    object_detection__demo()