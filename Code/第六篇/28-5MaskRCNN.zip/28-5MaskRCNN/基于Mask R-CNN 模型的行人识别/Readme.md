模型训练：

python train.py

模型测试（以**Penn-Fudan**数据为例）：

python inference2.py
