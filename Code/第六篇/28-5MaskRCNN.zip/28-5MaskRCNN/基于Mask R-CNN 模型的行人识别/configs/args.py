import os
import argparse

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

parser = argparse.ArgumentParser(description='Finetuning a pre-trained Mask R-CNN model in the Penn-Fudan Database for '
                                             'Pedestrian Detection and Segmentation.')
parser.add_argument('--dataset', default='D:/书稿/书稿2/PennFudanPed', type=str, help='dataset path')
parser.add_argument('--checkpoint', default=os.path.join('D:/书稿/书稿2/', 'model.pth'), type=str,
                    help='checkpoint save path')

args = parser.parse_args()


if __name__ == "__main__":
    print(args.checkpoint)