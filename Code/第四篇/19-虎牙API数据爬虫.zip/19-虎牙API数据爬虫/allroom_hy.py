from multiprocessing import Pool
from threading import Timer
import time
import datetime
import room_hy

# 5分钟爬一次
def crawl_1():
    # 记录该次爬取时间，为了便于后期的分析，开始爬取时记录当前的爬取时间作为该次爬取到的所有数据的爬取时间
    crawl_start_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')  # 爬取时间

    pool = Pool(processes = 2)
    groups = room_hy.get_catelist()
    pool.map(room_hy.get_result, groups)
    pool.close()
    pool.join()

    # 定时器，定时半小时执行爬取程序，计算整个过程一次爬取时间，1800-爬取所用时间为间隔时长
    now = time.strftime("%Y-%m-%d %H:%M:%S")
    crawl_space_time = 3*600.0 - (
        float(int(datetime.datetime.now().timestamp())) - time.mktime(
            time.strptime(crawl_start_time, '%Y-%m-%d %H:%M:%S')))
    next_time = (datetime.datetime.now() + datetime.timedelta(seconds=crawl_space_time)).strftime("%Y-%m-%d %H:%M:%S")
    if crawl_space_time < 0:
        crawl_space_time = 0
    print("==========================================================================================")
    print("       爬取结束!等待下一次爬取,现在是" + now + "下一次爬取将于[" + str(crawl_space_time) + "] 秒后,即" + next_time + "时进行……      ")
    # print("==========================================================================================")
    t = Timer(crawl_space_time, crawl_1)
    t.start()

if __name__ == '__main__':
    print("要开始爬取啦！现在是" + time.strftime("%Y-%m-%d %H:%M:%S"))
    crawl_1()
