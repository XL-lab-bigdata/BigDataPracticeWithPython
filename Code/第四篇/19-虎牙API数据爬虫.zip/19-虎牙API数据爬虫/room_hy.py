﻿# -*- coding: utf-8 -*-
import json
import time
import requests
import datetime
import re
import csv

# CSV文件路径
CSV_FILE = 'huya_live_data.csv'

# 请求HTML并处理重试机制
def open_html(url, retries=3):
    header = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36',
        'Connection': 'close'
    }
    try:
        session = requests.Session()
        session.keep_alive = False  # 禁用连接复用
        response = session.get(url, headers=header)
        response.raise_for_status()  # 请求失败时抛出异常
        return response.text
    except requests.exceptions.RequestException as e:
        print(f"请求 {url} 时出错: {e}")
        if retries > 0:
            print(f"重试中... 还剩 {retries} 次重试机会。")
            time.sleep(5)
            return open_html(url, retries - 1)
        else:
            print("最大重试次数已达，跳过该请求。")
            return None

# 获取分类列表
def get_catelist():
    url = 'https://www.huya.com/g'
    html = open_html(url)
    if html:
        try:
            catelist = re.findall('data-gid="(.*?)" ', html, re.S)
            return list(set(catelist))
        except re.error as e:
            print(f"解析分类列表时出错: {e}")
    return []

# 获取某个分类的总页数
def get_count(cateid):
    url = f'https://www.huya.com/cache.php?m=LiveList&do=getLiveListByPage&gameId={cateid}&tagAll=0&page=1'
    html = open_html(url)
    if html:
        try:
            content = json.loads(html)['data']
            return content.get('totalPage', 0)
        except json.JSONDecodeError as e:
            print(f"解析分类 {cateid} 时的JSON出错: {e}")
    return 0

# 获取分页数据
def get_pagedata(url):
    html = open_html(url)
    if html:
        try:
            content = json.loads(html)['data']
            return content.get('datas', [])
        except json.JSONDecodeError as e:
            print(f"解析分页数据时出错: {e}")
    return []

# 保存数据到CSV
def save_to_csv(result):
    if result:
        try:
            # 检查CSV文件是否存在，若不存在则写入表头
            file_exists = False
            try:
                with open(CSV_FILE, 'r', encoding='utf-8') as f:
                    file_exists = True
            except FileNotFoundError:
                pass

            with open(CSV_FILE, 'a', newline='', encoding='utf-8') as f:
                writer = csv.DictWriter(f, fieldnames=result.keys())
                if not file_exists:
                    writer.writeheader()  # 写入表头
                writer.writerow(result)
                print(f"成功保存到CSV: {result}")
                return True
        except Exception as e:
            print(f"保存数据到CSV时出错: {e}")
    return False

# 获取最终结果并保存到CSV
def get_result(cateid):
    pagecount = get_count(cateid)
    if pagecount > 0:
        for i in range(pagecount):
            url = f'https://www.huya.com/cache.php?m=LiveList&do=getLiveListByPage&gameId={cateid}&tagAll=0&page={i+1}'
            pagedata = get_pagedata(url)
            if not pagedata:
                break
            for data in pagedata:
                result = {}
                try:
                    result["user_id"] = data.get("uid")
                    result["nick_name"] = data.get("nick", "").encode('utf-8', 'ignore').decode('utf-8')
                    result["room_id"] = data.get("profileRoom")
                    result["room_name"] = data.get("roomName", "").encode('utf-8', 'ignore').decode('utf-8')
                    result["introduction"] = data.get("introduction", "").encode('utf-8', 'ignore').decode('utf-8')
                    result["now_host"] = data.get("privateHost", "").encode('utf-8', 'ignore').decode('utf-8')
                    result["recommend"] = data.get("recommendStatus")
                    result["fans"] = data.get("totalCount")
                    result["game_id"] = data.get("gameHostName")
                    result["game_name"] = data.get("gameFullName", "").encode('utf-8', 'ignore').decode('utf-8')
                    result['now_time'] = time.strftime("%Y-%m-%d %H:%M:%S")
                except Exception as e:
                    print(f"处理数据时出错: {e}")
                    continue
                save_to_csv(result)

if __name__ == "__main__":
    categories = get_catelist()
    if categories:
        for cateid in categories:
            get_result(cateid)
