# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class GubaScraperItem(scrapy.Item):
    post_id = scrapy.Field() #帖子id
    post_title = scrapy.Field() #帖子标题
    post_user_id = scrapy.Field() #发布帖子的用户id
    post_user_nickname = scrapy.Field() #发布帖子的用户昵称
    post_stockbar_code = scrapy.Field() # 贴子证券代码
    post_abstract = scrapy.Field() #帖子摘要
    post_content = scrapy.Field() #帖子内容
    post_publish_time = scrapy.Field() #帖子发布时间