# guba_scraper/spiders/guba_spider.py

import scrapy
import json
import re
from bs4 import BeautifulSoup
from guba_scraper.items import GubaScraperItem
import random

class GubaSpider(scrapy.Spider):
    name = 'guba_spider'
    allowed_domains = ['guba.eastmoney.com']
    start_urls = ['http://guba.eastmoney.com/list,gssz,f.html']

    # 自定义用户代理池
    user_agents = [
        'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_8; en-us) AppleWebKit/534.50 (KHTML, like Gecko) Version/5.1 Safari/534.50',
        'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-us) AppleWebKit/534.50 (KHTML, like Gecko) Version/5.1 Safari/534.50',
        'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)',
        'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.0; Trident/4.0)',
        'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0)',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1',
        'Mozilla/5.0 (Windows NT 6.1; rv:2.0.1) Gecko/20100101 Firefox/4.0.1',
        'Opera/9.80 (Macintosh; Intel Mac OS X 10.6.8; U; en) Presto/2.8.131 Version/11.11',
        'Opera/9.80 (Windows NT 6.1; U; en) Presto/2.8.131 Version/11.11',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_0) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.56 Safari/535.11',
        'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; Maxthon 2.0)',
        'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; TencentTraveler 4.0)',
    ]

    def start_requests(self):
        """
        生成要爬取的帖子列表页面URL，并发送请求到 parse_list 回调函数。
        爬取第1-10页。
        """
        for page in range(1, 11):  # 1到10页
            url = f'http://guba.eastmoney.com/list,gssz,f_{page}.html'
            yield scrapy.Request(url=url, callback=self.parse_list, headers=self.get_headers(), dont_filter=True)

    def get_headers(self):
        """
        随机选择一个 User-Agent 并设置请求头，以模拟不同的浏览器请求。
        """
        headers = {
            'Accept-Encoding': 'gzip, deflate, br, zstd',
            'Accept-Language': 'zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2',
            'Accept': '*/*',
            'Connection': 'closed',
            'User-Agent': random.choice(self.user_agents),
            'sec-ch-ua': '"Google Chrome";v="111", "Not(A:Brand";v="8", "Chromium";v="111"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"'
        }
        return headers

    def parse_list(self, response):
        """
        解析帖子列表页面，提取每个帖子的链接，并发送请求到 parse_post 回调函数。
        """
        # 使用XPath选择器定位帖子列表项
        listitems = response.xpath('//*[@id="mainlist"]/div/ul/li/table/tbody/tr')
        self.logger.info(f'Found {len(listitems)} posts on the page.')

        for listitem in listitems:
            post_href = listitem.xpath('./td[3]/div/a/@href').get()
            if post_href and 'gssz' in post_href:
                post_url = response.urljoin(post_href)
                yield scrapy.Request(url=post_url, callback=self.parse_post, headers=self.get_headers(), dont_filter=True)

    def parse_post(self, response):
        """
        解析单个帖子页面，提取所需的帖子信息，并生成Item。
        """
        item = GubaScraperItem()
        post_data_text = response.text

        # 使用正则表达式提取post_article变量的JSON内容
        match = re.search(r'var\s+post_article\s*=\s*(\{.*?\})\s*</script>', post_data_text, re.S)
        if match:
            try:
                json_result = json.loads(match.group(1))
                item['post_id'] = json_result.get("post_id", "")
                item['post_title'] = json_result.get("post_title", "")
                post_user = json_result.get("post_user", {})
                item['post_user_id'] = post_user.get("user_id", "")
                item['post_user_nickname'] = post_user.get("user_nickname", "")
                post_guba = json_result.get("post_guba", {})
                item['post_stockbar_code'] = post_guba.get("stockbar_code", "")
                post_content_html = json_result.get("post_content", "")
                # 使用BeautifulSoup去除HTML标签，仅保留纯文本内容
                soup = BeautifulSoup(post_content_html, 'html.parser')
                item['post_content'] = soup.get_text(strip=True)
                item['post_abstract'] = json_result.get("post_abstract", "")
                item['post_publish_time'] = json_result.get("post_publish_time", "")
                yield item
            except json.JSONDecodeError as e:
                self.logger.error(f"JSON decode error: {e}")
        else:
            self.logger.warning("No post_article found in the page.")
