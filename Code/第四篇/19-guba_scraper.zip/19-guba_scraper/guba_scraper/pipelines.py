# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from itemadapter import ItemAdapter




# guba_scraper/pipelines.py

import csv
# guba_scraper/pipelines.py

import csv

class GubaScraperPipeline:
    def open_spider(self, spider):
        """
        当爬虫启动时，打开CSV文件并写入表头。
        """
        self.file = open('guba_posts.csv', 'w', newline='', encoding='utf-8')
        self.writer = csv.DictWriter(self.file, fieldnames=[
            'post_id', 'post_title', 'post_user_id', 'post_user_nickname',
            'post_stockbar_code', 'post_abstract', 'post_content', 'post_publish_time'
        ])
        self.writer.writeheader()

    def close_spider(self, spider):
        """
        当爬虫关闭时，关闭CSV文件。
        """
        self.file.close()

    def process_item(self, item, spider):
        """
        将每个Item写入CSV文件。
        """
        self.writer.writerow(item)
        return item

